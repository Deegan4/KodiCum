# Cumnation — Kodi video add-on

A configurable video add-on for [Kodi](https://kodi.tv) (Matrix / Nexus /
Omega, i.e. Kodi 19+ with Python 3). It gives you a full browsing UI —
categories, search, favorites, watch history and resume — on top of a content
source you configure. The add-on is **content-source agnostic**: it reads from
a small JSON API whose URL you set in the add-on settings, so it is not tied to
any single website and ships nothing but the framework.

## Features

| Feature | Details |
| --- | --- |
| **Categories** | Browse the source's category tree, with per-page loading and a *Next page* item. |
| **Search** | Keyboard search with a persistent, de-duplicated search-history list. Remove single terms or clear all. |
| **Favorites** | Add/remove from the context menu; a dedicated Favorites folder; clear-all. |
| **Watch history** | Recently watched items are remembered (toggleable, size-capped). |
| **Resume** | Partially watched items resume where you left off; finished items reset automatically. |
| **Settings** | Base API URL, user-agent, page size, resume/history toggles, and maintenance actions. |

## Installation

1. Copy the `plugin.video.cumnation` folder into your Kodi `addons` directory,
   **or** zip it and install via *Add-ons → Install from zip file*.
2. Enable the add-on and open its **Settings**.
3. Set **Base API URL** to your content source (see the contract below).

## Content source contract

The add-on talks to a JSON API. Point **Base API URL** at the root; all paths
are relative to it.

```
GET {base}/categories
    -> {"categories": [{"id","name","url","thumb","plot","count"}, ...]}

GET {base}/list?category={id}&page={n}&limit={size}
    -> {"videos": [<video>...], "page": n, "has_next": bool}

GET {base}/search?q={query}&page={n}&limit={size}
    -> {"videos": [<video>...], "page": n, "has_next": bool}

GET {base}/resolve?id={video_id}[&url={page_url}]
    -> {"stream": "https://.../file.mp4", "headers": {...}}

<video> = {"id","title","url","thumb","plot","duration",
           "date","rating","tags"}
```

`headers` returned from `/resolve` are appended to the stream URL as Kodi
request headers (e.g. for `Referer`/`User-Agent`-gated CDNs).

## Try it without a backend

A reference backend is included. It serves Creative-Commons Blender open movies
so you can exercise the whole path — including playback — immediately:

```bash
python3 plugin.video.cumnation/resources/lib/mock_server.py 8080
# then set Base API URL to http://<your-ip>:8080
```

## Development

```bash
# byte-compile everything
python3 -m compileall plugin.video.cumnation

# run the off-device unit tests (Kodi is stubbed, no install needed)
python3 -m unittest discover -s tests
```

### Layout

```
plugin.video.cumnation/
├── addon.py                     # entry point (thin launcher)
├── addon.xml                    # add-on metadata & dependencies
└── resources/
    ├── settings.xml             # settings UI
    ├── language/…/strings.po    # localized strings
    └── lib/
        ├── router.py            # URL routing + directory building
        ├── content.py           # JSON content-source client
        ├── models.py            # Category / Video / Page
        ├── favorites.py         # favorites store
        ├── history.py           # search + watch history
        ├── resume.py            # resume points
        ├── player.py            # playback monitor for resume
        ├── storage.py           # JSON persistence
        ├── kodiutils.py         # Kodi API wrappers
        └── mock_server.py       # reference backend (not loaded by Kodi)
```

## Content responsibility

This add-on ships **no content and no scrapers** for any third-party site. You
are responsible for the source you connect it to and for complying with that
source's terms and with applicable law in your jurisdiction.

## License

MIT — see [LICENSE.txt](LICENSE.txt).
